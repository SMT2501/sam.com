# git-learning
#this repo was created when first time learning git 
#👋 Samkele
#👀 I’m interested in programing
#🌱 
#💞️ I’m looking to collaborate on every activity that will help me grow my programming skills
#📫 How to reach me .. ssmthuli@gmail.com
